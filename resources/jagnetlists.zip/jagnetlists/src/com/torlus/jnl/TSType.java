package com.torlus.jnl;

public enum TSType {
	NONE,
	IN,
	OUT,
	OE;
}

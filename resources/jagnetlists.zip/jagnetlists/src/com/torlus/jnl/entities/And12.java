package com.torlus.jnl.entities;

public class And12 extends An12 {
	public And12() {
		super();
	}
}

package com.torlus.jnl.entities;

public class Fd2qu extends Fd2q {
	// Same as Fd2q (?)
	public Fd2qu() {
		super();
	}
}

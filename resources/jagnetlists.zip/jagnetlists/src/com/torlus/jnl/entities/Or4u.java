package com.torlus.jnl.entities;

public class Or4u extends Or4 {
	public Or4u() {
		// Same as OR2 (?)
		super();
	}
}

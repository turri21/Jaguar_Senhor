package com.torlus.jnl.entities;

public class Or7 extends LG {
	public Or7() {
		// 260c_pri_e.pdf - COR8XL
		super(7, false, LGOp.OR);
	}
}

package com.torlus.jnl.entities;

public class Bu36da3m extends Buf {
	public Bu36da3m() {
		super();
	}
}

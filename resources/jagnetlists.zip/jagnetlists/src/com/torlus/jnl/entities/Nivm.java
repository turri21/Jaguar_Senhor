package com.torlus.jnl.entities;

public class Nivm extends Niv {
	public Nivm() {
		// Same as NIV (?)
		super();
	}
}

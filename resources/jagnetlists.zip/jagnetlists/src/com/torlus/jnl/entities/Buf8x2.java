package com.torlus.jnl.entities;

public class Buf8x2 extends Buf {
	public Buf8x2() {
		super();
	}
}

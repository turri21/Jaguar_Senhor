package com.torlus.jnl.entities;

public class Bniv310 extends Niv {
	public Bniv310() {
		// Same as NIV (?)
		super();
	}
}

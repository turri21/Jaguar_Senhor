package com.torlus.jnl.entities;

public class An2h extends An2 {
	public An2h() {
		// Same as AN2 (?)
		super();
	}
}

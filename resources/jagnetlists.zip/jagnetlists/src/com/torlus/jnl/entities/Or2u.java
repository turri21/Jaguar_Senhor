package com.torlus.jnl.entities;

public class Or2u extends Or2 {
	public Or2u() {
		// Same as OR2 (?)
		super();
	}
}

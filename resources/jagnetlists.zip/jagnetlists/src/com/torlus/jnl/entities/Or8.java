package com.torlus.jnl.entities;

public class Or8 extends LG {
	public Or8() {
		// 260c_pri_e.pdf - COR8XL
		super(8, false, LGOp.OR);
	}
}

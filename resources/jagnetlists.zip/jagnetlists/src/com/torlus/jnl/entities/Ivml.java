package com.torlus.jnl.entities;

public class Ivml extends Iv {
	public Ivml() {
		// Same as IV (?)
		super();
	}
}

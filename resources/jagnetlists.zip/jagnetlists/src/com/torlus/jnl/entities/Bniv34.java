package com.torlus.jnl.entities;

public class Bniv34 extends Niv {
	public Bniv34() {
		// Same as NIV (?)
		super();
	}
}

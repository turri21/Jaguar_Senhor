package com.torlus.jnl.entities;

public class Buf128 extends Buf {
	public Buf128() {
		super();
	}
}

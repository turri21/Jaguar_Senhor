package com.torlus.jnl.entities;

public class Nd2u extends Nd2 {
	public Nd2u() {
		// Same as ND2 (?)
		super();
	}
}

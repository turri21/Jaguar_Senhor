package com.torlus.jnl.entities;

public class Or3p extends Or3 {
	public Or3p() {
		// Same as OR3 (?)
		super();
	}
}

package com.torlus.jnl.entities;

public class Fd1qh extends Fd1q {
	// Same as Fd1q (?)
	public Fd1qh() {
		super();
	}
}

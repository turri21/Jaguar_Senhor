package com.torlus.jnl.entities;

public class Nd4p extends Nd4 {
	public Nd4p() {
		// Same as ND4 (?)
		super();
	}
}

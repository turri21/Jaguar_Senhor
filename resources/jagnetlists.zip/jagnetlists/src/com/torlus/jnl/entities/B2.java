package com.torlus.jnl.entities;

public class B2 extends B {
	public B2() {
		super();
	}
}

package com.torlus.jnl.entities;

public class Nr8 extends LG {
	public Nr8() {
		// 260c_pri_e.pdf - CNR8XL
		super(8, true, LGOp.OR);
	}
}

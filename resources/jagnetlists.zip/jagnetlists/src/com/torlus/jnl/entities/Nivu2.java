package com.torlus.jnl.entities;

public class Nivu2 extends Niv {
	public Nivu2() {
		// Same as NIV (?)
		super();
	}
}

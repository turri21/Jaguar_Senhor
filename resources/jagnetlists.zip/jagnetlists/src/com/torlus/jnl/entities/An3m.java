package com.torlus.jnl.entities;

public class An3m extends An3 {
	public An3m() {
		// Same as AN3 (?)
		super();
	}
}

package com.torlus.jnl.entities;

public class Or7m extends Or7 {
	public Or7m() {
		super();
	}
}

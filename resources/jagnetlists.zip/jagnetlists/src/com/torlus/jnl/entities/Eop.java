package com.torlus.jnl.entities;

public class Eop extends Eo {
	public Eop() {
		// Same as EO (?)
		super();
	}
}

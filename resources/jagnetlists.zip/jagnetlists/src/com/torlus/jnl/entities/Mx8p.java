package com.torlus.jnl.entities;

public class Mx8p extends Mx8 {
	public Mx8p() {
		// Same as MX8 (?)
		super();
	}
}

package com.torlus.jnl.entities;

public class Bt8 extends Bt {
	public Bt8() {
		super();
	}
}

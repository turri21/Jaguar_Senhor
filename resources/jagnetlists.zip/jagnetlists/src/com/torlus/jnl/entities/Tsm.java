package com.torlus.jnl.entities;

public class Tsm extends Ts {
	public Tsm() {
		// Same as TS (?)
		super();
	}
}

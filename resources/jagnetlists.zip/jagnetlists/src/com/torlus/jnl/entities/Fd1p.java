package com.torlus.jnl.entities;

public class Fd1p extends Fd1 {
	// Same as Fd1 (?)
	public Fd1p() {
		super();
	}
}

package com.torlus.jnl.entities;

public class Bu33ip7c extends Buf {
	public Bu33ip7c() {
		super();
	}
}

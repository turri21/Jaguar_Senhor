package com.torlus.jnl.entities;

public class Nd2 extends LG {
	public Nd2() {
		// 260c_pri_e.pdf - CND2XL
		super(2, true, LGOp.AND);
	}
}

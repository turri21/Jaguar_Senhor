package com.torlus.jnl.entities;

public class Mxi2p extends Mxi2 {
	public Mxi2p() {
		// Same as MXI2 (?)
		super();
	}
}

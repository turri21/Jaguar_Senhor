package com.torlus.jnl.entities;

public class Nr6 extends LG {
	public Nr6() {
		// 260c_pri_e.pdf - CNR6XL
		super(6, true, LGOp.OR);
	}
}

package com.torlus.jnl.entities;

public class Anr23 extends Anr2 {
	public Anr23() {
		// Same as ANR2 (?)
		super();
	}
}

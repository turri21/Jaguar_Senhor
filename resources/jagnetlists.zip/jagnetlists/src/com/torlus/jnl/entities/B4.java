package com.torlus.jnl.entities;

public class B4 extends B {
	public B4() {
		super();
	}
}

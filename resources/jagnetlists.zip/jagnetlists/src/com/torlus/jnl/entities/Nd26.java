package com.torlus.jnl.entities;

public class Nd26 extends LG {
	public Nd26() {
		super(26, true, LGOp.AND);
	}
	
}

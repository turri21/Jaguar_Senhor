package com.torlus.jnl.entities;

public class Fd2qp extends Fd2q {
	// Same as Fd2q (?)
	public Fd2qp() {
		super();
	}
}

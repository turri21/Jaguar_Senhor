package com.torlus.jnl.entities;

public class An2 extends LG {
	public An2() {
		// 260c_pri_e.pdf - CAN2XL
		super(2, false, LGOp.AND);
	}
}

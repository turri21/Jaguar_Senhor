package com.torlus.jnl.entities;

public class Or3 extends LG {
	public Or3() {
		// 260c_pri_e.pdf - COR3XL
		super(3, false, LGOp.OR);
	}
}

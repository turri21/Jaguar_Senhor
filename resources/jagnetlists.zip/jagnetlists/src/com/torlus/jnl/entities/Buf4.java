package com.torlus.jnl.entities;

public class Buf4 extends Buf {
	public Buf4() {
		super();
	}
}

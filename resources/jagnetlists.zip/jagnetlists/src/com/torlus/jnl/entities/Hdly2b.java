package com.torlus.jnl.entities;

public class Hdly2b extends Dly {
	public Hdly2b() {
		// Same as DLY (?)
		super();
	}
}

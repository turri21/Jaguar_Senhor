package com.torlus.jnl.entities;

public class An3h extends An3 {
	public An3h() {
		// Same as AN3 (?)
		super();
	}
}

package com.torlus.jnl.entities;

public class Nr3 extends LG {
	public Nr3() {
		// 260c_pri_e.pdf - CNR3XL
		super(3, true, LGOp.OR);
	}
}

package com.torlus.jnl.entities;

public class An4p extends An4 {
	public An4p() {
		// Same as AN4 (?)
		super();
	}
}

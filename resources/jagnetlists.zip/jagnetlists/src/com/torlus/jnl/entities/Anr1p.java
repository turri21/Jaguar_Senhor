package com.torlus.jnl.entities;

public class Anr1p extends Anr1 {
	public Anr1p() {
		// Same as ANR1 (?)
		super();
	}
}

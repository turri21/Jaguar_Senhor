package com.torlus.jnl.entities;

public class Mx4p extends Mx4 {
	public Mx4p() {
		// Same as MX4 (?)
		super();
	}
}

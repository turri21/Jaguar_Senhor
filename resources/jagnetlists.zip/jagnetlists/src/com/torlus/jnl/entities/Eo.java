package com.torlus.jnl.entities;

public class Eo extends LG {
	public Eo() {
		// 260c_pri_e.pdf - CEOXL
		super(2, false, LGOp.XOR);
	}
}

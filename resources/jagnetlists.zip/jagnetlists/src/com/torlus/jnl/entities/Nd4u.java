package com.torlus.jnl.entities;

public class Nd4u extends Nd4 {
	public Nd4u() {
		// Same as ND4 (?)
		super();
	}
}

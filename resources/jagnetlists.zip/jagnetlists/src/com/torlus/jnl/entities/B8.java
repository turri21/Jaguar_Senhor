package com.torlus.jnl.entities;

public class B8 extends B {
	public B8() {
		super();
	}
}

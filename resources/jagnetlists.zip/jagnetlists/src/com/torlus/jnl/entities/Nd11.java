package com.torlus.jnl.entities;

public class Nd11 extends LG {
	public Nd11() {
		super(11, true, LGOp.AND);
	}
	
}

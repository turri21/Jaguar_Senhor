package com.torlus.jnl.entities;

public class An3u extends An3 {
	public An3u() {
		// Same as AN3 (?)
		super();
	}
}

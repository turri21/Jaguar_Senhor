package com.torlus.jnl.entities;

public class Or9 extends LG {
	public Or9() {
		super(9, false, LGOp.OR);
	}
}

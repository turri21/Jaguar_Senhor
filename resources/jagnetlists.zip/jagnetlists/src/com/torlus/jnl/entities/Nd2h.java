package com.torlus.jnl.entities;

public class Nd2h extends Nd2 {
	public Nd2h() {
		// Same as ND2 (?)
		super();
	}
}

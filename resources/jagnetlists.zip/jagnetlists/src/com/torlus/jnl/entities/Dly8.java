package com.torlus.jnl.entities;

public class Dly8 extends Dly {
	public Dly8() {
		// Same as DLY8 (?)
		super();
	}
}

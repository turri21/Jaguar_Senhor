package com.torlus.jnl.entities;

public class Bd2t extends Bd {
	public Bd2t() {
		super();
	}
}

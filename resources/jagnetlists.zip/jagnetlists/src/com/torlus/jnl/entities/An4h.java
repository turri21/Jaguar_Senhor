package com.torlus.jnl.entities;

public class An4h extends An4 {
	public An4h() {
		// Same as AN4 (?)
		super();
	}
}

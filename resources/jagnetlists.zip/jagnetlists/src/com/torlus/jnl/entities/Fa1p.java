package com.torlus.jnl.entities;

public class Fa1p extends Fa1 {
	public Fa1p() {
		// Same as FA1 (?)
		super();
	}
}

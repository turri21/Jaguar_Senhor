package com.torlus.jnl.entities;

public class B16 extends B {
	public B16() {
		super();
	}
}

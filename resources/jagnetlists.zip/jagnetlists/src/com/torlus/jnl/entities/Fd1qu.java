package com.torlus.jnl.entities;

public class Fd1qu extends Fd1q {
	// Same as Fd1q (?)
	public Fd1qu() {
		super();
	}
}

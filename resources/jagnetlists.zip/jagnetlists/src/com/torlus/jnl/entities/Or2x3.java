package com.torlus.jnl.entities;

public class Or2x3 extends Or2 {
	public Or2x3() {
		// Same as OR2 (?)
		super();
	}
}

package com.torlus.jnl.entities;

public class Nr32 extends LG {
	public Nr32() {
		super(32, true, LGOp.OR);
	}
}

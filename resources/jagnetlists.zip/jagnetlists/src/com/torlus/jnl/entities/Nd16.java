package com.torlus.jnl.entities;

public class Nd16 extends LG {
	public Nd16() {
		super(16, true, LGOp.AND);
	}	
}

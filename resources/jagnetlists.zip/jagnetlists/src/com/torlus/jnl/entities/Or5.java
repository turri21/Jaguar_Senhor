package com.torlus.jnl.entities;

public class Or5 extends LG {
	public Or5() {
		super(5, false, LGOp.OR);
	}
}

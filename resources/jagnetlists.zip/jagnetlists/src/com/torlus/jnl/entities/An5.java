package com.torlus.jnl.entities;

public class An5 extends LG {
	public An5() {
		super(5, false, LGOp.AND);
	}
}

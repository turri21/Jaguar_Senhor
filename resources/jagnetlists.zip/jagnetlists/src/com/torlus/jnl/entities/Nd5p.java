package com.torlus.jnl.entities;

public class Nd5p extends Nd5 {
	public Nd5p() {
		super();
	}
}

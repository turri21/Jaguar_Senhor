package com.torlus.jnl.entities;

public class Buf24 extends Buf {
	public Buf24() {
		super();
	}
}

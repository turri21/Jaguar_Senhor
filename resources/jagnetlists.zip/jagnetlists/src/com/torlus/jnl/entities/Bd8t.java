package com.torlus.jnl.entities;

public class Bd8t extends Bd {
	public Bd8t() {
		super();
	}
}

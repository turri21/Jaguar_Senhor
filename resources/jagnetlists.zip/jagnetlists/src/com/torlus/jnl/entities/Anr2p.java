package com.torlus.jnl.entities;

public class Anr2p extends Anr2 {
	public Anr2p() {
		// Same as ANR2 (?)
		super();
	}
}

package com.torlus.jnl.entities;

public class Buf96 extends Buf {
	public Buf96() {
		super();
	}
}

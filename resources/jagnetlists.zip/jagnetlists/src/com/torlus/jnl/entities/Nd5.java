package com.torlus.jnl.entities;

public class Nd5 extends LG {
	public Nd5() {
		super(5, true, LGOp.AND);
	}
	
}

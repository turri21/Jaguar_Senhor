package com.torlus.jnl.entities;

public class En extends LG {
	public En() {
		// 260c_pri_e.pdf - CENXL
		super(2, true, LGOp.XOR);
	}
}

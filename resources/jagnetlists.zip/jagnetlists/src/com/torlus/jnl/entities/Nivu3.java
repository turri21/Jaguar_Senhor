package com.torlus.jnl.entities;

public class Nivu3 extends Niv {
	public Nivu3() {
		// Same as NIV (?)
		super();
	}
}

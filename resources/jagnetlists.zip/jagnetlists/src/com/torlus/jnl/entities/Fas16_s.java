package com.torlus.jnl.entities;

public class Fas16_s extends Fas16 {
	public Fas16_s() {
		super();
	}
}

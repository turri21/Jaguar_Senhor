package com.torlus.jnl.entities;

public class Nr3p extends Nr3 {
	public Nr3p() {
		// Same as NR3 (?)
		super();
	}
}

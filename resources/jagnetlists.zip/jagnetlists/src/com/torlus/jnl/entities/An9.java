package com.torlus.jnl.entities;

public class An9 extends LG {
	public An9() {
		// 260c_pri_e.pdf - CAN6XL
		super(9, false, LGOp.AND);
	}
}

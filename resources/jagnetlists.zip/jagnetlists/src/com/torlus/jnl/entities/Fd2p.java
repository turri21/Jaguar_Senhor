package com.torlus.jnl.entities;

public class Fd2p extends Fd2 {
	public Fd2p() {
		// Same as FD2 (?)
		super();
	}
}

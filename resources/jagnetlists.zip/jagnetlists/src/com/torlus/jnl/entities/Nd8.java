package com.torlus.jnl.entities;

public class Nd8 extends LG {
	public Nd8() {
		// 260c_pri_e.pdf - CND8XL
		super(8, true, LGOp.AND);
	}
}

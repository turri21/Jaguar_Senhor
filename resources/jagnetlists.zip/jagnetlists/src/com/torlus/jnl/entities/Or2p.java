package com.torlus.jnl.entities;

public class Or2p extends Or2 {
	public Or2p() {
		// Same as OR2 (?)
		super();
	}
}

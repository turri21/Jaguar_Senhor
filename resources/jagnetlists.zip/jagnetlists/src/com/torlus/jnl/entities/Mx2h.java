package com.torlus.jnl.entities;

public class Mx2h extends Mx2 {
	public Mx2h() {
		// Same as MX2 (?)
		super();
	}
}

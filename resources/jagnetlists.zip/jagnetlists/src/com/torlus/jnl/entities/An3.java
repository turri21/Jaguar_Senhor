package com.torlus.jnl.entities;

public class An3 extends LG {
	public An3() {
		// 260c_pri_e.pdf - CAN3XL
		super(3, false, LGOp.AND);
	}
}

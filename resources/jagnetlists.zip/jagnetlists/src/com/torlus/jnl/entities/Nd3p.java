package com.torlus.jnl.entities;

public class Nd3p extends Nd3 {
	public Nd3p() {
		// Same as ND3 (?)
		super();
	}
}

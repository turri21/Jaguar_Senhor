package com.torlus.jnl.entities;

public class Buf1 extends Buf {
	public Buf1() {
		super();
	}
}

package com.torlus.jnl.entities;

public class Nd3 extends LG {
	public Nd3() {
		// 260c_pri_e.pdf - CND3XL
		super(3, true, LGOp.AND);
	}
}

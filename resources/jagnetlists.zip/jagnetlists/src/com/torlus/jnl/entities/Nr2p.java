package com.torlus.jnl.entities;

public class Nr2p extends Nr2 {
	public Nr2p() {
		// Same as NR2 (?)
		super();
	}
}

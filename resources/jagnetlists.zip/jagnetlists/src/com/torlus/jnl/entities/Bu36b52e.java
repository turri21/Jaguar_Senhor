package com.torlus.jnl.entities;

public class Bu36b52e extends Buf {
	public Bu36b52e() {
		super();
	}
}

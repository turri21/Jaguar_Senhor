package com.torlus.jnl.entities;

public class Ivm extends Iv {
	public Ivm() {
		// Same as IV (?)
		super();
	}
}

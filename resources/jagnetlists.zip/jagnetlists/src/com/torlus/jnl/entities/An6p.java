package com.torlus.jnl.entities;

public class An6p extends An6 {
	public An6p() {
		// Same as AN6 (?)
		super();
	}
}

package com.torlus.jnl.entities;

public class And11 extends An11 {
	public And11() {
		super();
	}
}

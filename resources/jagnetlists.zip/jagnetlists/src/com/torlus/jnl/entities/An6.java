package com.torlus.jnl.entities;

public class An6 extends LG {
	public An6() {
		// 260c_pri_e.pdf - CAN6XL
		super(6, false, LGOp.AND);
	}
}

package com.torlus.jnl.entities;

public class Ivh extends Iv {
	public Ivh() {
		// Same as IV (?)
		super();
	}
}

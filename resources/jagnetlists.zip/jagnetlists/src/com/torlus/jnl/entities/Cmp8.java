package com.torlus.jnl.entities;

public class Cmp8 extends CmpN {
	public Cmp8() {
		super(8);
	}
}

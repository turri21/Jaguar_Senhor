package com.torlus.jnl.entities;

public class Nd2m extends Nd2 {
	public Nd2m() {
		// Same as ND2 (?)
		super();
	}
}

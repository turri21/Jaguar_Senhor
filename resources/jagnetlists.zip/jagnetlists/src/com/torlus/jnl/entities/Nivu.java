package com.torlus.jnl.entities;

public class Nivu extends Niv {
	public Nivu() {
		// Same as NIV (?)
		super();
	}
}

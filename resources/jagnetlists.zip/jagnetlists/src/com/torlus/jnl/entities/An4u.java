package com.torlus.jnl.entities;

public class An4u extends An4 {
	public An4u() {
		// Same as AN4 (?)
		super();
	}
}

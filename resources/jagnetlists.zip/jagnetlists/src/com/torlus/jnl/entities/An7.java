package com.torlus.jnl.entities;

public class An7 extends LG {
	public An7() {
		super(7, false, LGOp.AND);
	}
}

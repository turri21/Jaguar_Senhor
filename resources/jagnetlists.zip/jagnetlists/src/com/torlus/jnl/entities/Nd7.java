package com.torlus.jnl.entities;

public class Nd7 extends LG {
	public Nd7() {
		super(7, true, LGOp.AND);
	}
	
}

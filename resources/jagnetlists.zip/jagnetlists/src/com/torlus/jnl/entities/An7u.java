package com.torlus.jnl.entities;

public class An7u extends An7 {
	public An7u() {
		// Same as AN7 (?)
		super();
	}
}

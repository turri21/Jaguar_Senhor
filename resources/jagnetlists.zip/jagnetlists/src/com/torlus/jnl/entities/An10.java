package com.torlus.jnl.entities;

public class An10 extends LG {
	public An10() {
		super(10, false, LGOp.AND);
	}
}

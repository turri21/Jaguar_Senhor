package com.torlus.jnl.entities;

public class Or4 extends LG {
	public Or4() {
		// 260c_pri_e.pdf - COR4XL
		super(4, false, LGOp.OR);
	}
}

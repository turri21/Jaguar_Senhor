package com.torlus.jnl.entities;

public class An3p extends An3 {
	public An3p() {
		// Same as AN3 (?)
		super();
	}
}

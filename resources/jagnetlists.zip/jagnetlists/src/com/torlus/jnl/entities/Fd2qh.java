package com.torlus.jnl.entities;

public class Fd2qh extends Fd2q {
	// Same as Fd2q (?)
	public Fd2qh() {
		super();
	}
}

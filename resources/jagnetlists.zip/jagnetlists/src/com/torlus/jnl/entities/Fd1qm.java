package com.torlus.jnl.entities;

public class Fd1qm extends Fd1q {
	// Same as Fd1q (?)
	public Fd1qm() {
		super();
	}
}

package com.torlus.jnl.entities;

public class Buf8x6 extends Buf {
	public Buf8x6() {
		super();
	}
}

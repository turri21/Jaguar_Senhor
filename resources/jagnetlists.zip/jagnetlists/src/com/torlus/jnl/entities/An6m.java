package com.torlus.jnl.entities;

public class An6m extends An6 {
	public An6m() {
		// Same as AN6 (?)
		super();
	}
}

package com.torlus.jnl.entities;

public class Ra8008c extends Ra8008a {
	@Override
	public String getBaseName() {
		return "ra8008c";
	}

	public Ra8008c() {
		super();
	}
}

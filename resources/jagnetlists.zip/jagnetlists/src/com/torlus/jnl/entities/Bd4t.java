package com.torlus.jnl.entities;

public class Bd4t extends Bd {
	public Bd4t() {
		super();
	}
}

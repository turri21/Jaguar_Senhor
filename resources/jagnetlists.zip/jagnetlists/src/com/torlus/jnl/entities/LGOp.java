package com.torlus.jnl.entities;

public enum LGOp {
	AND, OR, XOR
}

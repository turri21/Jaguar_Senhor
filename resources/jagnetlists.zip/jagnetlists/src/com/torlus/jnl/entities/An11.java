package com.torlus.jnl.entities;

public class An11 extends LG {
	public An11() {
		super(11, false, LGOp.AND);
	}
}

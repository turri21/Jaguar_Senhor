package com.torlus.jnl.entities;

public class Nd3h extends Nd3 {
	public Nd3h() {
		// Same as ND3 (?)
		super();
	}
}

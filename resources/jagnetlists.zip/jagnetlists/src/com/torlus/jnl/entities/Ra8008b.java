package com.torlus.jnl.entities;

public class Ra8008b extends Ra8008a {
	@Override
	public String getBaseName() {
		return "ra8008b";
	}

	public Ra8008b() {
		super();
	}
}

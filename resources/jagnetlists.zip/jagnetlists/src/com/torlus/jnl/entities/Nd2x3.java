package com.torlus.jnl.entities;

public class Nd2x3 extends Nd2 {
	public Nd2x3() {
		// Same as ND2 (?)
		super();
	}
}

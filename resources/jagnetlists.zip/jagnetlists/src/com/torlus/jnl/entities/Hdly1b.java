package com.torlus.jnl.entities;

public class Hdly1b extends Dly {
	public Hdly1b() {
		// Same as DLY (?)
		super();
	}
}

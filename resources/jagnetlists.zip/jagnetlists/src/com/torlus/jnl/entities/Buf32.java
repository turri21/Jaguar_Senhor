package com.torlus.jnl.entities;

public class Buf32 extends Buf {
	public Buf32() {
		super();
	}
}

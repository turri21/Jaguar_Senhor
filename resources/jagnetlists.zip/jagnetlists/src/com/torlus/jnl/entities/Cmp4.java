package com.torlus.jnl.entities;

public class Cmp4 extends CmpN {
	public Cmp4() {
		super(4);
	}
}

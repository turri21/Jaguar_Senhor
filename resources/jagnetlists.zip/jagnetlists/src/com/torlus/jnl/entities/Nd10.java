package com.torlus.jnl.entities;

public class Nd10 extends LG {
	public Nd10() {
		super(10, true, LGOp.AND);
	}
	
}

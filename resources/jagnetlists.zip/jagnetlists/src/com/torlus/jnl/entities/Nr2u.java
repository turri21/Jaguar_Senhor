package com.torlus.jnl.entities;

public class Nr2u extends Nr2 {
	public Nr2u() {
		// Same as NR2 (?)
		super();
	}
}

package com.torlus.jnl.entities;

public class Or3_h extends Or3 {
	public Or3_h() {
		// Same as OR3 (?)
		super();
	}
}

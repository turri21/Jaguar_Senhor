package com.torlus.jnl.entities;

public class An4 extends LG {
	public An4() {
		// 260c_pri_e.pdf - CAN4XL
		super(4, false, LGOp.AND);
	}
}

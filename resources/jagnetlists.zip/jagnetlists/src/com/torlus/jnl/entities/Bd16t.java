package com.torlus.jnl.entities;

public class Bd16t extends Bd {
	public Bd16t() {
		super();
	}
}

package com.torlus.jnl.entities;

public class Or6 extends LG {
	public Or6() {
		// 260c_pri_e.pdf - COR6XL
		super(6, false, LGOp.OR);
	}
}

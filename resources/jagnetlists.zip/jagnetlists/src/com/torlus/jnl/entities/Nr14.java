package com.torlus.jnl.entities;

public class Nr14 extends LG {
	public Nr14() {
		super(14, true, LGOp.OR);
	}
}

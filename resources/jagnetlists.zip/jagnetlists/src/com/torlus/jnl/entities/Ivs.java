package com.torlus.jnl.entities;

public class Ivs extends Iv {
	public Ivs() {
		// Same as IV (?)
		super();
	}
}

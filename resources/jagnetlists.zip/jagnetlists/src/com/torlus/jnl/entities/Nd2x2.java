package com.torlus.jnl.entities;

public class Nd2x2 extends Nd2 {
	public Nd2x2() {
		// Same as ND2 (?)
		super();
	}
}

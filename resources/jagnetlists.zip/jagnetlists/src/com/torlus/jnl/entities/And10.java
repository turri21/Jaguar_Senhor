package com.torlus.jnl.entities;

public class And10 extends An10 {
	public And10() {
		super();
	}
}

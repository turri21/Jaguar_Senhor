package com.torlus.jnl.entities;

public class Nr5 extends LG {
	public Nr5() {
		super(5, true, LGOp.OR);
	}
}

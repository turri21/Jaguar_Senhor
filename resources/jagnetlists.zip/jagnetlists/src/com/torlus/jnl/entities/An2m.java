package com.torlus.jnl.entities;

public class An2m extends An2 {
	public An2m() {
		// Same as AN2 (?)
		super();
	}
}

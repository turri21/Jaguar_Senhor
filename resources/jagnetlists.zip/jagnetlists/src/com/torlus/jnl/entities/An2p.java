package com.torlus.jnl.entities;

public class An2p extends An2 {
	public An2p() {
		// Same as AN2 (?)
		super();
	}
}

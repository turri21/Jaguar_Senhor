package com.torlus.jnl.entities;

public class Buf64 extends Buf {
	public Buf64() {
		super();
	}
}

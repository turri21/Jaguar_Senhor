package com.torlus.jnl.entities;

public class Nr4p extends Nr4 {
	public Nr4p() {
		// Same as NR4 (?)
		super();
	}
}

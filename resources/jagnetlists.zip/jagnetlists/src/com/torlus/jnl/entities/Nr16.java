package com.torlus.jnl.entities;

public class Nr16 extends LG {
	public Nr16() {
		super(16, true, LGOp.OR);
	}
}

package com.torlus.jnl.entities;

public class Buf48 extends Buf {
	public Buf48() {
		super();
	}
}

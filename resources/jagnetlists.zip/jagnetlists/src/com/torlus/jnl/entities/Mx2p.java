package com.torlus.jnl.entities;

public class Mx2p extends Mx2 {
	public Mx2p() {
		// Same as MX2 (?)
		super();
	}
}

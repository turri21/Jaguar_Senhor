package com.torlus.jnl.entities;

public class Fd2h extends Fd2 {
	public Fd2h() {
		// Same as FD2 (?)
		super();
	}
}

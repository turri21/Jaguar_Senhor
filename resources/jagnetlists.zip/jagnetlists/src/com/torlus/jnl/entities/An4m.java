package com.torlus.jnl.entities;

public class An4m extends An4 {
	public An4m() {
		// Same as AN4 (?)
		super();
	}
}

package com.torlus.jnl.entities;

public class Aor1p extends Aor1 {
	public Aor1p() {
		// Same as AOR1 (?)
		super();
	}
}

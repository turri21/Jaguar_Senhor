package com.torlus.jnl.entities;

public class An2u extends An2 {
	public An2u() {
		// Same as AN2 (?)
		super();
	}
}

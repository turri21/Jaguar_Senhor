package com.torlus.jnl.entities;

public class Buf16 extends Buf {
	public Buf16() {
		super();
	}
}

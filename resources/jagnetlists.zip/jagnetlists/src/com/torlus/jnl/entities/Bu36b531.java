package com.torlus.jnl.entities;

public class Bu36b531 extends Buf {
	public Bu36b531() {
		super();
	}
}

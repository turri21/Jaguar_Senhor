package com.torlus.jnl.entities;

public class Nd6 extends LG {
	public Nd6() {
		// 260c_pri_e.pdf - CND6XL
		super(6, true, LGOp.AND);
	}
}

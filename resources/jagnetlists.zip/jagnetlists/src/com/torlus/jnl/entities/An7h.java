package com.torlus.jnl.entities;

public class An7h extends An7 {
	public An7h() {
		// Same as AN7 (?)
		super();
	}
}

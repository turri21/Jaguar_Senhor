package com.torlus.jnl.entities;

public class An6u extends An6 {
	public An6u() {
		// Same as AN6 (?)
		super();
	}
}

package com.torlus.jnl.entities;

public class Nd2p extends Nd2 {
	public Nd2p() {
		// Same as ND2 (?)
		super();
	}
}

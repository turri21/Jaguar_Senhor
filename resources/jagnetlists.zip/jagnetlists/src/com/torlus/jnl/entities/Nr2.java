package com.torlus.jnl.entities;

public class Nr2 extends LG {
	public Nr2() {
		// 260c_pri_e.pdf - CNR2XL
		super(2, true, LGOp.OR);
	}
}

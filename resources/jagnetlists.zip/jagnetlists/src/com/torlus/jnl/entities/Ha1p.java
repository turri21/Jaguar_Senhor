package com.torlus.jnl.entities;

public class Ha1p extends Ha1 {
	// Same as Ha1 (?)
	public Ha1p() {
		super();
	}
}

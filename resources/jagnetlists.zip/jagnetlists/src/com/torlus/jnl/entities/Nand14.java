package com.torlus.jnl.entities;

public class Nand14 extends Nd14 {
	public Nand14() {
		super();
	}
	
}

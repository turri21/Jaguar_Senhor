package com.torlus.jnl.entities;

public class Ivu extends Iv {
	public Ivu() {
		// Same as IV (?)
		super();
	}
}

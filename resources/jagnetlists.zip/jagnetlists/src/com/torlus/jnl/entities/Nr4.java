package com.torlus.jnl.entities;

public class Nr4 extends LG {
	public Nr4() {
		// 260c_pri_e.pdf - CNR4XL
		super(4, true, LGOp.OR);
	}
}

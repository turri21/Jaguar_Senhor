package com.torlus.jnl.entities;

public class Nd4 extends LG {
	public Nd4() {
		// 260c_pri_e.pdf - CND4XL
		super(4, true, LGOp.AND);
	}
	
}

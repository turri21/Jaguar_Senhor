package com.torlus.jnl.entities;

public class Nd9 extends LG {
	public Nd9() {
		super(9, true, LGOp.AND);
	}
	
}

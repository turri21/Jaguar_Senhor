package com.torlus.jnl.entities;

public class An5p extends An5 {
	public An5p() {
		super();
	}
}

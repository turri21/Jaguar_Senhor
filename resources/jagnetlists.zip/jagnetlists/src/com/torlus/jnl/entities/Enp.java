package com.torlus.jnl.entities;

public class Enp extends En {
	public Enp() {
		// Same as EN (?)
		super();
	}
}

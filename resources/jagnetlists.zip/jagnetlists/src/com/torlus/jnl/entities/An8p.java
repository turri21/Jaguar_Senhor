package com.torlus.jnl.entities;

public class An8p extends An8 {
	public An8p() {
		// Same as AN8 (?)
		super();
	}
}

package com.torlus.jnl.entities;

public class Or3u extends Or3 {
	public Or3u() {
		// Same as OR3 (?)
		super();
	}
}

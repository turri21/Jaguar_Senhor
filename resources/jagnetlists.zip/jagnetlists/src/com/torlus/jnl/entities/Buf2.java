package com.torlus.jnl.entities;

public class Buf2 extends Buf {
	public Buf2() {
		super();
	}
}

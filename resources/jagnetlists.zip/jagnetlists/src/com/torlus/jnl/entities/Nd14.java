package com.torlus.jnl.entities;

public class Nd14 extends LG {
	public Nd14() {
		super(14, true, LGOp.AND);
	}
	
}

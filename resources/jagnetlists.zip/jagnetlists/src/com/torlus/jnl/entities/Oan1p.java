package com.torlus.jnl.entities;

public class Oan1p extends Oan1 {
	public Oan1p() {
		// Same as OAN1 (?)
		super();
	}
}

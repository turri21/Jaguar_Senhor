package com.torlus.jnl.entities;

public class Nr26 extends LG {
	public Nr26() {
		super(26, true, LGOp.OR);
	}
}

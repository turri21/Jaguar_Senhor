package com.torlus.jnl.entities;

public class Or2 extends LG {
	public Or2() {
		// 260c_pri_e.pdf - COR2XL
		super(2, false, LGOp.OR);
	}
}

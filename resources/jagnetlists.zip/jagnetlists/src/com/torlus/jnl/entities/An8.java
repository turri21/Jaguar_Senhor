package com.torlus.jnl.entities;

public class An8 extends LG {
	public An8() {
		// 260c_pri_e.pdf - CAN8XL
		super(8, false, LGOp.AND);
	}
}

package com.torlus.jnl.entities;

public class An12 extends LG {
	public An12() {
		super(12, false, LGOp.AND);
	}
}

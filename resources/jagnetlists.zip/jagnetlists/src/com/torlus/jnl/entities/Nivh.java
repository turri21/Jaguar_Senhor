package com.torlus.jnl.entities;

public class Nivh extends Niv {
	public Nivh() {
		// Same as NIV (?)
		super();
	}
}

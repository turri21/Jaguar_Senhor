package com.torlus.jnl.entities;

public class Fd2qm extends Fd2q {
	// Same as Fd2q (?)
	public Fd2qm() {
		super();
	}
}

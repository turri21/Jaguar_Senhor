package com.torlus.jnl.entities;

public class B8h extends B {
	public B8h() {
		super();
	}
}

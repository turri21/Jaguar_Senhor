package com.torlus.jnl.entities;

public class Or16 extends LG {
	public Or16() {
		super(16, false, LGOp.OR);
	}
}

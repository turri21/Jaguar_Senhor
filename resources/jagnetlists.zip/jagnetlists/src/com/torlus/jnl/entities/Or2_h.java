package com.torlus.jnl.entities;

public class Or2_h extends Or2 {
	public Or2_h() {
		// Same as OR2 (?)
		super();
	}
}
